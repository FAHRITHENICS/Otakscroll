OTAK SCROLL - CARA MENDAPATKAN APK

Proyek ini sudah disiapkan dengan workflow untuk membangun APK secara otomatis.
Lingkungan pembuatan di sesi ini tidak memiliki Android SDK/Gradle, sehingga APK
belum dapat dikompilasi langsung di sini.

LANGKAH:
1. Buat repository baru di GitHub.
2. Upload seluruh isi folder OtakScroll ini ke repository (file build.gradle.kts,
   settings.gradle.kts, folder app, dan folder .github harus berada di root repository).
3. Buka tab Actions pada repository.
4. Pilih workflow "Build Otak Scroll APK" lalu tekan "Run workflow".
5. Setelah proses selesai, buka hasil workflow dan unduh artifact
   "OtakScroll-debug-apk".
6. Ekstrak file ZIP artifact. Di dalamnya ada app-debug.apk.
7. Buka APK tersebut di HP Android dan izinkan pemasangan dari sumber yang
   digunakan jika Android memintanya.
8. Buka aplikasi Otak Scroll, lalu tekan tombol untuk membuka Pengaturan
   Aksesibilitas dan aktifkan layanan Otak Scroll.

CATATAN:
- Ini adalah debug APK untuk pemasangan dan pengujian pribadi.
- Layanan Aksesibilitas diperlukan agar aplikasi dapat menghitung peristiwa scroll.
- Aplikasi saat ini menghitung scroll pada paket aplikasi yang tercantum di
  ScrollService.kt. Periksa daftar tersebut sebelum digunakan.
