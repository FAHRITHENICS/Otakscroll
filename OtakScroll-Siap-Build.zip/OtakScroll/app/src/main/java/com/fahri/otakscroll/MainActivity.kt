package com.fahri.otakscroll

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var info: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.rgb(255, 245, 249))
        }
        root.addView(BrainView(this).also { it.count = todayCount() })
        info = TextView(this).apply { textSize = 20f; gravity = Gravity.CENTER; setTextColor(Color.rgb(90, 40, 70)) }
        root.addView(info)
        val btn = Button(this).apply {
            text = "Aktifkan di Pengaturan Aksesibilitas"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        root.addView(btn)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        info.text = "Hari ini kamu scroll\n${todayCount()} kali"
    }

    private fun todayCount(): Int {
        val key = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        return getSharedPreferences("scroll", MODE_PRIVATE).getInt(key, 0)
    }
}
