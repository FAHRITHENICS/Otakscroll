package com.fahri.otakscroll

import android.content.Context
import android.graphics.*
import android.view.View

class BrainView(context: Context) : View(context) {
    var count = 0
        set(v) { field = v; blink(); invalidate() }
    private var eyesClosed = false
    private val d = resources.displayMetrics.density
    private val pink = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 154, 190) }
    private val dark = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(200, 90, 130); style = Paint.Style.STROKE; strokeWidth = 2 * d; strokeCap = Paint.Cap.ROUND }
    private val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val black = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(40, 30, 40) }
    private val blush = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(120, 255, 90, 120) }
    private val bubble = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(230, 255, 255, 255) }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(90, 40, 70); textSize = 14 * d; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
    }

    private fun blink() {
        eyesClosed = true
        postDelayed({ eyesClosed = false; invalidate() }, 150)
    }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension((120 * d).toInt(), (96 * d).toInt())

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = 36 * d
        // badan otak: beberapa gumpalan
        c.drawCircle(cx - 20 * d, cy, 22 * d, pink)
        c.drawCircle(cx + 20 * d, cy, 22 * d, pink)
        c.drawCircle(cx, cy - 12 * d, 22 * d, pink)
        c.drawCircle(cx, cy + 8 * d, 22 * d, pink)
        // lipatan otak
        c.drawLine(cx, cy - 30 * d, cx, cy - 14 * d, dark)
        val p = Path().apply {
            moveTo(cx - 34 * d, cy - 6 * d); quadTo(cx - 26 * d, cy - 14 * d, cx - 18 * d, cy - 6 * d)
            moveTo(cx + 34 * d, cy - 6 * d); quadTo(cx + 26 * d, cy - 14 * d, cx + 18 * d, cy - 6 * d)
        }
        c.drawPath(p, dark.apply { style = Paint.Style.STROKE })
        // mata
        for (ex in floatArrayOf(cx - 11 * d, cx + 11 * d)) {
            if (eyesClosed) {
                c.drawLine(ex - 5 * d, cy + 4 * d, ex + 5 * d, cy + 4 * d, dark)
            } else {
                c.drawCircle(ex, cy + 4 * d, 8 * d, white)
                c.drawCircle(ex + 1.5f * d, cy + 6 * d, 4 * d, black)
                c.drawCircle(ex + 3 * d, cy + 4 * d, 1.5f * d, white)
            }
        }
        // pipi + senyum
        c.drawCircle(cx - 22 * d, cy + 15 * d, 4 * d, blush)
        c.drawCircle(cx + 22 * d, cy + 15 * d, 4 * d, blush)
        c.drawArc(RectF(cx - 6 * d, cy + 10 * d, cx + 6 * d, cy + 20 * d), 20f, 140f, false, dark)
        // balon hitungan
        val r = RectF(cx - 45 * d, 72 * d, cx + 45 * d, 94 * d)
        c.drawRoundRect(r, 11 * d, 11 * d, bubble)
        c.drawText("$count scroll", cx, r.centerY() + 5 * d, text)
    }
}
