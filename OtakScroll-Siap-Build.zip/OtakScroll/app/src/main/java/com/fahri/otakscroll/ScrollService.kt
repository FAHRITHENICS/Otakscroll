package com.fahri.otakscroll

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.os.SystemClock
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import java.text.SimpleDateFormat
import java.util.*

class ScrollService : AccessibilityService() {

    private var brain: BrainView? = null
    private var shown = false
    private var lastScroll = 0L

    // Ubah daftar ini kalau mau tambah/kurangi aplikasi
    private val targets = setOf(
        "com.instagram.android",
        "com.zhiliaoapp.musically",   // TikTok
        "com.ss.android.ugc.trill",   // TikTok (versi lain)
        "com.twitter.android",        // X
        "com.facebook.katana",
        "com.google.android.youtube",
        "com.whatsapp"
    )

    private val prefs by lazy { getSharedPreferences("scroll", MODE_PRIVATE) }
    private fun today() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    override fun onServiceConnected() {
        brain = BrainView(this).also { it.count = prefs.getInt(today(), 0) }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        when (e.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                if (pkg == "com.android.systemui" || pkg.contains("inputmethod") || pkg.contains("keyboard")) return
                if (pkg in targets) showBrain() else hideBrain()
            }
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                if (pkg !in targets) return
                showBrain()
                val now = SystemClock.elapsedRealtime()
                // satu swipe menghasilkan banyak event; hitung 1 kali per gerakan
                if (now - lastScroll > 350) {
                    val n = prefs.getInt(today(), 0) + 1
                    prefs.edit().putInt(today(), n).apply()
                    brain?.count = n
                }
                lastScroll = now
            }
        }
    }

    private fun showBrain() {
        if (shown) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 80 }
        brain?.count = prefs.getInt(today(), 0)
        wm.addView(brain, lp)
        shown = true
    }

    private fun hideBrain() {
        if (!shown) return
        (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(brain)
        shown = false
    }

    override fun onInterrupt() {}
    override fun onUnbind(intent: android.content.Intent?): Boolean { hideBrain(); return super.onUnbind(intent) }
}
